#include "criarconta.h"    // (O nome do arquivo .h)
#include "ui_criarconta.h" // <--- 1. MUDE AQUI (para bater com o .ui)
// (Assumindo que o arquivo é CriarConta.ui)

// 2. MUDE AQUI (Nome da classe e inicialização da UI)
CriarConta::CriarConta(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::CriarConta) // <--- MUDE AQUI
{
    ui->setupUi(this);
}

// 3. MUDE AQUI
CriarConta::~CriarConta()
{
    delete ui;
}
