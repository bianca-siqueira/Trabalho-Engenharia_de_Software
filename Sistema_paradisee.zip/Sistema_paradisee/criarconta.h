#ifndef CRIARCONTA_H
#define CRIARCONTA_H

#include <QDialog>

namespace Ui {
class CriarConta;
}

class CriarConta : public QDialog
{
    Q_OBJECT

public:
    explicit CriarConta(QWidget *parent = nullptr);
    ~CriarConta();

private:

    Ui::CriarConta *ui;
};

#endif // CRIARCONTA_H
